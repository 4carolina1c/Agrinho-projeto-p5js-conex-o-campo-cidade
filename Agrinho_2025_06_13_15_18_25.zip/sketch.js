let personagem;

let itensCampo = [];

let itensCidade = [];

let obstáculos = [];

let score = 0;

function setup() {

  createCanvas(800, 600);

  personagem = new Personagem();

  for (let i = 0; i < 5; i++) {

    itensCampo.push(new Item(random(width), random(height / 2), 'campo'));

    itensCidade.push(new Item(random(width), random(height / 2, height), 'cidade'));

  }

  for (let i = 0; i < 3; i++) {

    obstáculos.push(new Obstacle(random(width), random(height), 50, 50));

  }

}

function draw() {

  background(220);

  personagem.move();

  personagem.display();

  for (let item of itensCampo) {

    item.display();

    if (personagem.collect(item)) {

      score += 10;

      itensCampo = itensCampo.filter(i => i !== item);

    }

  }

  for (let item of itensCidade) {

    item.display();

    if (personagem.collect(item)) {

      score += 20;

      itensCidade = itensCidade.filter(i => i !== item);

    }

  }

  for (let obst of obstáculos) {

    obst.display();

    if (personagem.collidesWith(obst)) {

      score -= 5;

      personagem.reset();

    }

  }

  fill(0);

  textSize(24);

  text("Pontos: " + score, 20, 30);

}

class Personagem {

  constructor() {

    this.x = 100;

    this.y = height / 2;

    this.size = 40;

    this.speed = 5;

  }

  move() {

    if (keyIsDown(LEFT_ARROW)) {

      this.x -= this.speed;

    }

    if (keyIsDown(RIGHT_ARROW)) {

      this.x += this.speed;

    }

    if (keyIsDown(UP_ARROW)) {

      this.y -= this.speed;

    }

    if (keyIsDown(DOWN_ARROW)) {

      this.y += this.speed;

    }

  }

  display() {

    fill(255, 0, 0);

    ellipse(this.x, this.y, this.size, this.size);

  }

  collect(item) {

    let d = dist(this.x, this.y, item.x, item.y);

    return d < this.size / 2 + item.size / 2;

  }

  collidesWith(obstacle) {

    let d = dist(this.x, this.y, obstacle.x, obstacle.y);

    return d < this.size / 2 + obstacle.size / 2;

  }

  reset() {

    this.x = 100;

    this.y = height / 2;

  }

}

class Item {

  constructor(x, y, tipo) {

    this.x = x;

    this.y = y;

    this.size = 30;

    this.tipo = tipo;

  }

  display() {

    if (this.tipo === 'campo') {

      fill(34, 139, 34); // Cor do campo (verde)

    } else {

      fill(255, 223, 0); // Cor da cidade (amarelo)

    }

    ellipse(this.x, this.y, this.size, this.size);

  }

}

class Obstacle {

  constructor(x, y, w, h) {

    this.x = x;

    this.y = y;

    this.width = w;

    this.height = h;

  }

  display() {

    fill(150, 75, 0);

    rect(this.x, this.y, this.width, this.height);

  }

}

